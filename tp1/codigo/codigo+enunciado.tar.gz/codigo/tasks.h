#ifndef __TASKS_H__
#define __TASKS_H__

#include "basetask.h"
void tasks_init(void);

#endif
